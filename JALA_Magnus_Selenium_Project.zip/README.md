# JALA Magnus Selenium Assignment — Java/TestNG/POM

## Deliverables
- `test-cases.csv`: 15 manual test scenarios.
- `src/main/java/com/jala/pages/LoginPage.java`: Page Object Model for login page.
- `src/test/java/com/jala/tests/BaseTest.java`: WebDriver setup/teardown.
- `src/test/java/com/jala/tests/LoginTests.java`: six starter TestNG tests.
- `src/test/resources/testng.xml`: TestNG suite configuration.
- `JIRA-defect-report.md`: one observed concern and four candidate defects to verify.

## Run in Eclipse
1. Install JDK 17+, Maven, and Chrome.
2. Extract the ZIP and import it into Eclipse: File → Import → Maven → Existing Maven Projects.
3. Run `mvn test` from the project directory.
4. To run valid login, pass the training password as a system property: `mvn test -Dmagnus.password=YOUR_TRAINING_PASSWORD`. Do not commit the password to source control.
5. Review actual test results. Adjust CSS locators if the site's DOM differs from the selectors.

## Important limitation
The live public pages were inspected, but this environment did not submit the login/recovery forms or run a real browser session. Therefore no test execution is falsely marked Pass, and only the displayed training credentials are reported as an observed concern. Four other defect reports are clearly marked candidates and must be reproduced before filing. The assignment asks for five defects, so use the candidate checks to find four additional genuine issues and attach screenshots.
