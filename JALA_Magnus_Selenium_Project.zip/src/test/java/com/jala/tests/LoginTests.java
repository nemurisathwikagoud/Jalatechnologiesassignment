package com.jala.tests;
import com.jala.pages.LoginPage;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

public class LoginTests extends BaseTest {
 private static final String USER=System.getProperty("magnus.user","training@jalaacademy.com");
 private static final String PASS=System.getProperty("magnus.password","");
 @Test public void TC01_loginPageLoads(){ LoginPage p=new LoginPage(driver); p.open(); Assert.assertTrue(driver.getTitle().toLowerCase().contains("login"),"Expected login page title"); Assert.assertTrue(p.passwordVisible(),"Password input should be visible"); }
 @Test public void TC02_rememberMeControlPresent(){ LoginPage p=new LoginPage(driver); p.open(); Assert.assertTrue(p.rememberControlExists(),"Remember Me checkbox should be present"); }
 @Test public void TC03_forgotPasswordLinkPresent(){ LoginPage p=new LoginPage(driver); p.open(); Assert.assertTrue(p.forgotPasswordExists(),"Forgot Password link should be present"); }
 @Test public void TC04_emptyCredentialsDoNotAuthenticate(){ LoginPage p=new LoginPage(driver); p.open(); p.submit(); Assert.assertTrue(p.passwordVisible(),"After empty submit, user should remain on login form"); }
 @Test public void TC05_invalidPasswordDoesNotAuthenticate(){ LoginPage p=new LoginPage(driver); p.open(); p.login(USER,"WrongPassword_123!NotReal"); try{Thread.sleep(1000);}catch(InterruptedException e){Thread.currentThread().interrupt();} Assert.assertTrue(p.passwordVisible(),"Invalid credentials must not authenticate"); }
 @Test public void TC06_validLogin(){ if(PASS.isBlank()) throw new SkipException("Set -Dmagnus.password=... to run this test."); LoginPage p=new LoginPage(driver); p.open(); p.login(USER,PASS); try{Thread.sleep(1200);}catch(InterruptedException e){Thread.currentThread().interrupt();} Assert.assertFalse(p.passwordVisible(),"Successful login should leave login form"); }
}
