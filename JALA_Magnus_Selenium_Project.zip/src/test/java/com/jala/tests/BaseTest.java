package com.jala.tests;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import io.github.bonigarcia.wdm.WebDriverManager;
public class BaseTest {
 protected WebDriver driver;
 @BeforeMethod public void setUp(){ WebDriverManager.chromedriver().setup(); driver=new ChromeDriver(); driver.manage().window().maximize(); }
 @AfterMethod(alwaysRun=true) public void tearDown(){ if(driver!=null) driver.quit(); }
}
