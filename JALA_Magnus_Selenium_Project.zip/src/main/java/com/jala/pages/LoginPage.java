package com.jala.pages;

import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/** Page Object for the Magnus login screen. Verify locators against the live DOM before execution. */
public class LoginPage {
    private final WebDriver driver;
    private final WebDriverWait wait;
    private final By email = By.cssSelector("input[type='email'], input[name*='Email'], input[placeholder*='Email'], input[placeholder*='Mobile']");
    private final By password = By.cssSelector("input[type='password']");
    private final By submit = By.cssSelector("button[type='submit'], input[type='submit']");
    private final By remember = By.cssSelector("input[type='checkbox']");
    private final By forgotPassword = By.cssSelector("a[href*='ForgotPassword']");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    public void open() { driver.get("https://magnus.jalatechnologies.com/"); }
    public boolean passwordVisible() { return !driver.findElements(password).isEmpty() && driver.findElement(password).isDisplayed(); }
    public boolean rememberControlExists() { return !driver.findElements(remember).isEmpty(); }
    public boolean forgotPasswordExists() { return !driver.findElements(forgotPassword).isEmpty(); }
    public void enterEmail(String value) { WebElement e=wait.until(ExpectedConditions.visibilityOfElementLocated(email)); e.clear(); e.sendKeys(value); }
    public void enterPassword(String value) { WebElement p=wait.until(ExpectedConditions.visibilityOfElementLocated(password)); p.clear(); p.sendKeys(value); }
    public void submit() { wait.until(ExpectedConditions.elementToBeClickable(submit)).click(); }
    public void login(String user, String pass) { enterEmail(user); enterPassword(pass); submit(); }
}
